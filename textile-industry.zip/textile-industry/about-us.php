<!doctype html>
<html lang="en">
   <head>
      <title>about-us</title>

   </head>
   <body>
   <?php include 'header.php';?>
      <section class="container-x container-y about-banner" style="background-image: url(assets/images/bg.jpg);background-repeat: no-repeat;background-size: cover; background-position: center;">
         <div class="flex-box">
            <div class="center">
               <h1>About Us</h1>
               
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.

</p>
            </div>
         </div>
      </section>

      <section class="container-x container-y mid">
         <div class="flex-box">
            <div class="about-col-lt"><img src="assets/images/Vision.png" alt="Vision"></div>
            <div class="about-col-rt">
            <h2>Vision</h2>
               <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel 

</h4>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel 
</p>
               <ul>
                  <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum 

</li>
                  <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
</li>
                  <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                  <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                  <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
               </ul>
            </div>
         </div>
      </section>
      <section class="container-x container-y mid-white">
         <div class="flex-box">
            <div class="about-col-rt">
               <h2>History</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel metus eu varius. Praesent tortor justo, consectetur ac massa at, imperdiet ullamcorper odio. Curabitur venenatis arcu vitae lacus finibus tempus. Nunc suscipit ut risus ac fermentum. Proin non urna placerat, pharetra diam in, interdum ex. Etiam a efficitur est. Sed hendrerit imperdiet malesuada. In blandit quam vel odio hendrerit, vel vehicula felis iaculis. Nulla elementum eros quis dolor malesuada pulvinar.

</p>
            </div>
            <div class="about-col-lt"><img src="assets/images/History-1.png" alt="History"></div>
         </div>
      </section>

 <?php include 'footer.php';?>

   </body>
</html>