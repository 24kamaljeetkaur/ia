<!doctype html>
<html lang="en">
   <head>
      <title>Outerwear/Apparel Fabrics</title>
      <link rel="stylesheet" type="text/css" href="assets/css/style-service.css">
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="container-x container-y banner-prod" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/Banner-img.jpg);background-image:url(assets/images/Banner-img.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Services </h1>
            </div>
         </div>
      </section>
      <section class="container-x container-y integrated-content">
         <div class="flex-box">
            <div class="inner-content">
               <p>We offer an integrated services portfolio from weaving to finishing, giving an added advantage of a seamless process and control at every stage of product lifecycle. Continuously innovating to add new product lines and our expand our capability</p>
            </div>
         </div>
      </section>

<section class="container-x container-y service-mid">
         <div class="flex-box">
            <div class="service-col-lt"><img src="assets/images/Fabric.jpg" alt="service"></div>
            <div class="service-col-rt">
            <h2>Fabric Manufacturing</h2>
               <p> Starting as a Blanket Manufacturer, we have built a capability to produce a wide variety of products in Woollen and Worsted range producing Outerwear/apparel fabrics to very specialised Endless industrial Felts.  This has been possible because of continuous upgrade of machinery as well as innovative thinking in our manufacturing processes and designs.  The daily production capacity has grown multifold over the years with the possibility to work with a wide variety of yarns like wool, polywool, polyester etc.  the unit is spread over 50000 sqft area with a daily production capacity of upto 20000 mtr.</p>
            </div>
         </div>
      </section>
      <section class="container-x container-y service-mid">
         <div class="flex-box">
            <div class="service-col-lt"><img src="assets/images/Proccessing.jpg" alt="service"></div>
            <div class="service-col-rt">
            <h2> Processign & finishing</h2>
               <p>Ktex has evolved with changing times and customer needs by creation of an inhouse woollen processing unit covering an extensive area of 1,00,000 sq ft and having a finishing capacity of 20,000 mts per day. Using innovative and world-class, state of art infrastructure development as its core strategy, this processing unit has been instrumental in retaining Kochartex’s position as a one-stop shop for woven woollen fabrics.</p>
               <p> We have the capacity to carry out numerous processes to provide various finishes to fabrics and ensure great quality.</p>
            </div>
         </div>
      </section>
      <?php include 'footer.php';?>
   </body>
</html>