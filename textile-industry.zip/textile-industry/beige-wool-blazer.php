<!doctype html>
<html lang="en">
   <head>
      <title>Product Categories</title>
     
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="container-x container-y zoom-box">
         <h6><a href="#">&#60;&nbsp;Back to listing</a></h6>
         <div class="flex-box">
            <div class="zoom-lt">
               <img src="assets/images/zoom.jpg" alt="beige wool blazer">
            </div>
            <div class="zoom-rt">
               <h1>Beige Wool Blazer</h1>
               <!-- <p>Swatch Details</p> -->
               <div class="flex-box">
                  <div class="listing">
                     <h5>Article:
                           <span>Q-no. 10096</span>
                        </h5>
                  </div>
                   <div class="listing">
                      <h5>Width:
                           <span>54-Inches</span>
                        </h5>
                   </div>
                    <div class="listing">
                       <h5>Color:
                           <span>Beige</span>
                        </h5>
                    </div>
                     <div class="listing">
                        <h5>Weight:
                           <span>525 Gms</span>
                        </h5>
                     </div>
               </div>

                        <!-- <h5>Composition:
                           <span>70% wool,  20% nylon , 10% fine wool and so on</span>
                           </h5> -->
                        <table class="composition">
                           <tr>
                              <td>
                                 <h5>Composition:</h5>
                              </td>
                              <td>
                                 <h5>Type</h5>
                              </td>
                           </tr>
                           <tr>
                              <td>70%</td>
                              <td>Wool</td>
                           </tr>
                           <tr>
                              <td>20%</td>
                              <td>Nylon</td>
                           </tr>
                           <tr>
                              <td>10%</td>
                              <td>Fine wool</td>
                           </tr>
                        </table>

               <a href="#" id="popup"  data-toggle="modal" data-target="#exampleModal"> Request a Quote </a>
               <!-- The Modal -->
               <!-- Button trigger modal -->
               <!-- Modal -->
               <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title" id="exampleModalLabel">Request a quote</h5>
                        </div>
                        <div class="modal-body">
                           <p>Form Here</p>
                        </div>
                        <div class="modal-footer">
                           <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="container-x container-y requestquote ">
         <h2>Related Products</h2>
         <div class="flex-box">
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Beige Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Black Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Blue Grey Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Dark Red Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Grey Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Blue Wool Blazer</h5>
               </div>
            </div>
         </div>
      </section>
      <?php include 'footer.php';?>
   </body>
</html>