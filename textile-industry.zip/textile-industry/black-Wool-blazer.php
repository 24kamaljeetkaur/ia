<!DOCTYPE html>
<html>
<head>
	<title>Black Wool Blazer</title>

</head>
<body>
<?php include 'header.php';?>
 <h1 style="padding-top: 80px;">Black Wool Blazer</h1>
 <?php include 'footer.php';?>
</body>
</html>