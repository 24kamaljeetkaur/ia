<!doctype html>
<html lang="en">
   <head>
      <title>Blankets & Shawls</title>

   </head>
   <body>
<?php include 'header.php';?>
      <section class="container-x container-y banner-prod" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/Blanket.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Blankets & Shawls</h1>
            </div>
         </div>
      </section>

      <section class="container-x container-y product-woollentext">
         <div class="flex-box">
            <div class="inner-content">
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel metus eu varius. Praesent tortor justo, consectetur ac massa at, imperdiet ullamcorper odio. Curabitur venenatis arcu vitae lacus finibus tempus. Nunc suscipit ut risus ac fermentum. Proin non urna placerat, pharetra diam in, interdum ex. Etiam a efficitur est. Sed hendrerit imperdiet malesuada. In blandit quam vel odio hendrerit, vel vehicula felis iaculis. Nulla elementum eros quis dolor malesuada pulvinar.

</p>
            </div>
         </div>
      </section>
      <section class="container-x container-y blankets-mid">
         <div class="flex-box">
            <div class="about-col-lt"><img src="assets\images\blanket-inside.jpg" alt="Shoddy Woollen Blankets"></div>
            <div class="about-col-rt">
               <h2>Shoddy Woollen Blankets</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel metus eu varius. Praesent tortor justo, consectetur ac massa at, imperdiet ullamcorper odio. Curabitur venenatis arcu vitae lacus finibus tempus. Nunc suscipit ut risus ac fermentum. Proin non urna placerat, pharetra diam in, interdum ex. Etiam a efficitur est. Sed hendrerit imperdiet malesuada. In blandit quam vel odio hendrerit, vel vehicula felis iaculis. Nulla elementum eros quis dolor malesuada pulvinar.

</p>
                              <div class=" cta">
   <div class="btn-overlay"><a href="#">Request a Quote</a></div>
</div>
            </div>
         </div>
      </section>
      <section class="container-x container-y blankets-mid">
         <div class="flex-box">
            <div class="about-col-lt">
               <img src="assets\images\throws.jpg" alt="Throw Blankets">
            </div>
            <div class="about-col-rt">
               <h2>Throw Blankets</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In blandit quam vel odio hendrerit, vel vehicula felis iaculis. Nulla elementum eros quis dolor malesuada pulvinar:</p>
               <ul>
                  <li>Large throw blankets are 40X60'</li>
                  <li>Small throw Blankets are 30×50'. </li>
               </ul>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel metus eu varius. Praesent tortor justo, consectetur ac massa at, imperdiet ullamcorper odio. Curabitur venenatis arcu vitae lacus finibus tempus. Nunc suscipit ut risus ac fermentum. Proin non urna placerat, pharetra diam in, interdum ex. Etiam a efficitur est. Sed hendrerit imperdiet malesuada. In blandit quam vel odio hendrerit, vel vehicula felis iaculis. Nulla elementum eros quis dolor malesuada pulvinar.

</p>
                              <div class=" cta">
   <div class="btn-overlay"><a href="#">Request a Quote</a></div>
</div>
            </div>
         </div>
      </section>
 <?php include 'footer.php';?>

   </body>
</html>