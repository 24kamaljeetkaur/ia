<!DOCTYPE html>
<html>
<head>
	<title>Blue Grey Wool Blazer</title>

</head>
<body>
<?php include 'header.php';?>
 <h1 style="padding-top: 80px;">Blue Grey Wool Blazer</h1>
  <?php include 'footer.php';?>
</body>
</html>