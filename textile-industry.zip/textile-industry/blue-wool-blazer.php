<!DOCTYPE html>
<html>
<head>
	<title>Blue Wool Blazer</title>

</head>
<body>
<?php include 'header.php';?>
 <h1 style="padding-top: 80px;">Blue Wool Blazer</h1>
 
  <?php include 'footer.php';?>
</body>
</html>