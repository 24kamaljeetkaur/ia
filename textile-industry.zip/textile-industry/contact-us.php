<!doctype html>
<html lang="en">
   <head>
      <title>Contact us</title>
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="container-x container-y banner-ct" style="background-image:linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),  url(assets/images/img-contacus-bg.jpg);">
       <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Contact us</h1>
            </div>
         </div>
      </section>
      <section class="container-x container-y cont-form">
      <div class="shadow-form">
         <h2>Get In Touch</h2>
          <p><a href="mailto:wool@kochar.com">LoremIpsum@.com,</a> <a href="mailto:enquiry@kochar.com">LoremIpsum@.com</a></p>
          <!-- <p><a href="tel:9915356789">+91-9915356789</a></p> -->
            <form>                     
               <input type="text" name="" placeholder="Name">
               <input type="email" name="" placeholder="Email">
               <input type="text" name="" placeholder="Phone number">
               <textarea placeholder="Message"></textarea>
               <input type="submit" value="Submit">
            </form>
         </div>
      </section>
       <!-- <section class="container-y container-x  enq-box">
         <div class="flex-box">
            <fieldset class="block-col">
            
                 <legend><h4>Corporate Office</h4></legend>

               <p> Kochar Woolen Mills Pvt. Ltd. P.O.</p>
               <p> Golden Temple, Katra Ahluwalia</p>
               <p>Amritsar-143006 Punjab, India</p>
               <p>Ph. No:
                  <a href="tel:0183-2552792">0183-2552792,</a> 
                  <a href="tel:2552238">2552238</a>, 
                  <a href="tel:5004201">5004201</a>
               </p>
            </fieldset>
            <fieldset class="block-col">
               <legend><h4>Processing Units</h4></legend>
               <p> Kochar Woolen Processors </p>
               <p>P. O. Four Feild, G.T. Road,</p>
               <p>Amritsar, Punjab, India</p>
               <p>Ph. No:
                  <a href="tel:0183-2589966">0183-2589966,</a> 
               </p>
            </fieldset>
            <fieldset class="block-col">
               <legend><h4>Factory Kochar Bhawan</h4></legend>
               <p>Kochar Woolen Mills Pvt. Ltd.</p>
               <p>SultanWind Road, Opp. 100 Feet Road,</p>
               <p>Amritsar-143001, India</p>
               <p>Ph. No:
                  <a href="tel:0183-2491045"> 0183-2491045,</a> 
                  <a href="tel:2491046">2491046</a>, 
                  <a href="tel:2483248">2483248</a>
               </p>
            </fieldset>
         </div>
        </section> -->


      <?php include 'footer.php';?>
   </body>
</html>