<!DOCTYPE html>
<html>
<head>
	<title>Dark Red Wool Blazer</title>

</head>
<body>
<?php include 'header.php';?>
 <h1 style="padding-top: 80px;">Dark Red Wool Blazer</h1>
  <?php include 'footer.php';?>
</body>
</html>