<!DOCTYPE html>
<html>
<head>
	<title>Fabric Manufacturing</title>

</head>
<body>
<?php include 'header.php';?>
 <h1 style="padding-top: 80px;">Fabric Manufacturing</h1>
 <?php include 'footer.php';?>
</body>
</html>