<!doctype html>
<html lang="en">
   <head>
      <title>Flame Retardant Fabric</title>
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="container-x container-y banner-prod" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/Flame.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Flame Retardant Fabric</h1>
            </div>
         </div>
      </section>
      <section class="container-x container-y product-woollentext">
         <div class="flex-box">
            <div class="inner-content">
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel metus eu varius. Praesent tortor justo, consectetur ac massa at, imperdiet ullamcorper odio. Curabitur venenatis arcu vitae lacus finibus tempus. Nunc suscipit ut risus ac fermentum. Proin non urna placerat, pharetra diam in, interdum ex. Etiam a efficitur est. Sed hendrerit imperdiet malesuada. In blandit quam vel odio hendrerit, vel vehicula felis iaculis. Nulla elementum eros quis dolor malesuada pulvinar.

</p>
               
            </div>
         </div>
      </section>
            <section class="container-x container-y blankets-mid">
         <div class="flex-box">
            <div class="about-col-lt"><img src="assets\images\Flame-Retardant.jpg" alt="Flame Retardant Fabric"></div>
            <div class="about-col-rt">
               <h2>Product</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel metus eu varius. Praesent tortor justo, consectetur ac massa at, imperdiet ullamcorper odio. Curabitur venenatis arcu vitae lacus finibus tempus. Nunc suscipit ut risus ac fermentum. Proin non urna placerat, pharetra diam in, interdum ex. Etiam a efficitur est. Sed hendrerit imperdiet malesuada. In blandit quam vel odio hendrerit, vel vehicula felis iaculis. Nulla elementum eros quis dolor malesuada pulvinar.

</p>
               <b>Benefit of Wool based Products</b>
               <ul>
                  <li>Excellent Acoustic Properties</li>
                  <li>Flame & Fire Resistant</li>
                  <li>Great Insulation</li>
               </ul>
               <b>Following options are available in wool:</b>
               <ul>
                  <li>Flame Proofed Blankets (500 / 600 / 700 GSM)</li>
                  <li>Coloured & Chromakey Wool Serge</li>
                  <li>Superior Wool Serge - 300/500 gm</li>
                  <li>Heavy Wool Serge – 625 gm</li>
               </ul>
                <div class=" cta">
                 <div class="btn-overlay">
                  <a href="#">Request a Quote</a>
                 </div>
                </div>
            </div>
         </div>
      </section>
      <?php include 'footer.php';?>
   </body>
</html>