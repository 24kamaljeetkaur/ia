<!doctype html>
<html lang="en">

   <body>
      <footer>
         <div class="main-top-footer">
            <div class="flex-box footer-px">
               <div class="footer-block">
                  <h3>Products</h3>
                  <ul class=" mr-l">
                     <li><a href="outerwear-apparel-fabrics.php">Outerwear/Apparel Fabrics</a></li>
                     <li><a href="sports-fabrics.php">Sports Fabrics</a></li>
                     <li><a href="industrial-fabrics.php">Industrial Fabrics</a></li>
                     <li><a href="flame-retardant-fabric.php">Flame Retardant Fabric</a></li>
                     <li><a href="institutional-fabrics.php">Institutional Fabrics</a></li>
                     <li><a href="blankets-and-shawls.php">Blankets & Shawls</a></li>
                     <li><a href="">Woollen Garments</a></li>
                     <li><a href="">Ethnic Wear</a></li>
                  </ul>
               </div>

               <!-- <div class="footer-block">
                  <h3>Services</h3>
                  <ul>
                     <li><a href="fabric-manufacturing.php">Fabric Manufacturing</a></li>
                     <li><a href="woollen-processing.php">Woollen Processing</a></li>
                  </ul>
               </div> -->
               <div class="footer-block">
                  <h3>Quick Links</h3>
                  <ul>
                     <li><a href="about-us.php">About us</a></li>
                     <li><a href="service.php">Service</a></li>

                     <li><a href="contact-us.php">Contact us</a></li>
                  </ul>
               </div>
               <div class="footer-block">
                  
                  <div class="flex-box">
                     <div class="certification"><img src="assets\images\.png"></div>
                     <div class="certification"><img src="assets\images\R.png"></div>
                     <div class="certification"><img src="assets\images\.png"></div>
                  </div>
                  <!-- <form role="search" method="get" action="https://Kochartex.com/">
                     <input type="search" placeholder="Search Products…" value="" name="s" title="Search for:">
                     <input type="submit" value="Search">
                     </form> -->
               </div>
            </div>
         </div>
         <div class="copyrigthbar">
            <div class="flex-box">
               <div class="cpyrgt-left">
                  <p><a href="https://www.kochar.com/">Lorem Ipsum</a> | Lorem-Ipsum Division</p>
                  <p>Copyright © 0000 <a href="https://kochartex.com/">LoremIpsum</a>, All Lorem Ipsum Reserved.</p>
               </div>
               <!-- <div class="cpyrgt-right"><img src="assets\images\img-bscic.png"></div> -->
            </div>
         </div>
      </footer>
   </body>
</html>