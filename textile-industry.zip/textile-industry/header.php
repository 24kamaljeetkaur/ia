<!doctype html>
<html lang="en">
   <head>
      
      <link rel="icon" href="assets/images/Fav1.png" type="image/x-icon">
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="assets\css\style.css">
      <link href="https://fonts.googleapis.com/css?family=Titillium+Web:100,200,300,400,500,600,700,900" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Oswald:100,200,300,400,500,600,700" rel="stylesheet">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <!-- Owl Stylesheets -->
      <!-- https://bbbootstrap.com/snippets/basic-carousel-slider-owl-carousel-19760944 -->
      <link rel="stylesheet" href="assets/js/owl.carousel.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" >
   </head>
   <body>
      <nav class="navbar navbar-expand-md">
         <a class="navbar-brand" href="index.php">LOGO</a>
         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarNavAltMarkup">
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
         <span class="icon-bar"></span>
         </button>
         <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <ul  class="navbar-nav ml-auto">
               <!-- <li id="menu-item-111" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-355 nav-item"><a itemprop="url" href="https://leapmax.ai/features/" class="nav-link"><span itemprop="name">Products</span></a></li> -->
               <li class="nav-item menu-item-has-children dropdown">
                  <a href="products.php" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle" id="navbarDropdown" role="button"><span itemprop="name">Products</span></a>
                  <ul class="dropdown-menu">
                     <li  class="nav-item"><a itemprop="url" href="outerwear-apparel-fabrics.php" class="dropdown-item"><span itemprop="name">Outerwear/Apparel Fabrics</span></a></li>
                     <li  class="nav-item"><a itemprop="url" href="sports-fabrics.php" class="dropdown-item"><span itemprop="name">Sports Fabrics</span></a></li>
                     <li  class="nav-item"><a itemprop="url" href="industrial-fabrics.php" class="dropdown-item"><span itemprop="name">Industrial Fabrics</span></a></li>
                     <li  class="nav-item"><a itemprop="url" href="flame-retardant-fabric.php" class="dropdown-item"><span itemprop="name">Flame Retardant Fabric</span></a></li>
                     <li  class="nav-item"><a itemprop="url" href="institutional-fabrics.php" class="dropdown-item"><span itemprop="name">Institutional Fabrics</span></a></li>
                     <li  class="nav-item"><a itemprop="url" href="blankets-and-shawls.php" class="dropdown-item"><span itemprop="name">Blankets & Shawls</span></a></li>
                     <li  class="nav-item"><a itemprop="url" href="" class="dropdown-item" target="_blank"><span itemprop="name">Woollen Garments</span></a></li>
                     <li  class="nav-item"><a itemprop="url" href="" class="dropdown-item" target="_blank"><span itemprop="name">Ethnic Wear</span></a></li>
                  </ul>
               </li>


               <!-- <li id="menu-item-773" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown menu-item-773 nav-item">
                  <a href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle nav-link" id="menu-item-dropdown-773"><span itemprop="name">Resources</span></a>
                  <ul class="dropdown-menu" aria-labelledby="menu-item-dropdown-773">
                     <li id="menu-item-359" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-359 nav-item"><a itemprop="url" href="https://leapmax.ai/blog/" class="dropdown-item"><span itemprop="name">Blog</span></a></li>
                     <li id="menu-item-774" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-774 nav-item"><a itemprop="url" href="https://leapmax.ai/case-study/" class="dropdown-item"><span itemprop="name">Case Studies</span></a></li>
                  </ul>
                  </li> -->
               <li class="nav-item"><a itemprop="url" href="about-us.php" class="nav-link"><span itemprop="name">About Us</span></a></li>
               <li class="nav-item"><a itemprop="url" href="service.php" class="nav-link"><span itemprop="name">Service</span></a></li>

               <li class="nav-item"><a itemprop="url" href="contact-us.php" class="nav-link"><span itemprop="name">Contact us</span></a></li>
            </ul>
         </div>
      </nav>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script>
         $(document).ready(function(){
           $(".navbar-toggle").click(function(){
             $(".show").toggle(1000);
           });
         });
      </script>

   </body>
</html>