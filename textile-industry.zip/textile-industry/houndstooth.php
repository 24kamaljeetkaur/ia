<!doctype html>
<html lang="en">
   <head>
      <title>Houndstooth</title>
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="container-x container-y banner-prod" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/Houndstooth.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Houndstooth Fabric</h1>
            </div>
         </div>
      </section>

      <!-- <section class="container-x container-y blankets-mid">
         <div class="flex-box">
            <div class="about-col-lt"><img src="assets\images\Houndstooth.jpg" alt="Houndstooth"></div>
            <div class="about-col-rt">
               <h2>Jacquard</h2>
               <p>We manufacture Jacquard fabrics which have interesting and complex patterns. Jacquard is woven into a fabric having different patterns such as damasks, floral, curvy and geometrical designs. Both sides of jacquard wool fabric can be used in manufacturing clothes or decorative items. Jacquard weaves have a varying drape ability and durability depending on which fibres are used. These jacquards are generally made of worsted, woollen yarns, regenerated fibre yarns in any composition basis the requirement from the customer. This fabric is manufactured with finest quality of raw material catering to customer’s specifications. You will find numerous styles and colors of Jacquard fabric in this section.</p>
            </div>
         </div>
      </section> -->
      <section class="container-x container-y requestquote ">
         <div class="flex-box">
            <div class="requestquote-block">
               <img src="assets/images/21.jpg" alt="Beige & Black Single Face Houndstooth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Beige & Black Single Face Houndstooth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/22.jpg" alt="Green and White Clearer cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Beige & Black Single Face Houndstooth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/23.jpg" alt="Frictional flannel">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Beige & Red Single Face Houndstooth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/24.jpg" alt="Plaiding cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Beige Black Single Face Houndstooth</h5>
               </div>
            </div>
            
             <div class="requestquote-block">
               <img src="assets/images/25.jpg" alt="Endless Clearer cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Beige Black Single Face Houndstooth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/26.jpg" alt="Green and White Clearer cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Beige Black Single Face Houndstooth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/27.jpg" alt="Frictional flannel">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Beige Black Single Face Houndstooth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/28.jpg" alt="Plaiding cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Black Beige Single Face Houndstooth</h5>
               </div>
            </div>

             <div class="requestquote-block">
               <img src="assets/images/29.jpg" alt="Endless Clearer cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Black Fawn Single Face Houndstooth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/30.jpg" alt="Green and White Clearer cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Black Grey Single Face Houndstooth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/31.jpg" alt="Frictional flannel">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Green Black Single Face Houndstooth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/32.jpg" alt="Plaiding cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Grey & Black Single Face Houndstooth</h5>
               </div>
            </div>
         </div>

      </section>



      <?php include 'footer.php';?>
   </body>
</html>