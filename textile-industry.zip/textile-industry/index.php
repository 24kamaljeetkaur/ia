<!doctype html>
<html lang="en">
   <head>
      <title>Home</title>
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="banner-slide">
         <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
               <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
               <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            </ol>
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <img src="assets/images/Banner1.jpg" class="d-block w-100" alt="Fabric Innovation">
                  <div class="carousel-caption d-none d-md-block animate-fading-h1">
                     <div class="bg-black-col">
                        <h1>Lorem Ipsum is simply dummy text of the printing and typesetting industry. <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</span> Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h1>
                        <h4>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>
                        <!-- <a href="#">Request a Quote</a> -->
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <img src="assets/images/Blankets3.jpg" class="d-block w-100" alt="Global Exporters ">
                  <div class="carousel-caption d-none d-md-block animate-fading-h1">
                     <div class="bg-black-col">
                        <h1>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h1>
                        <!-- <a href="#">Request a Quote</a> -->
                     </div>
                  </div>
               </div>
               <!-- <div class="carousel-item">
                  <img src="assets/images/Banner-3.jpg" class="d-block w-100" alt="Leveraging Technology">
                  <div class="carousel-caption d-none d-md-block animate-fading-h1">
                     <div class="bg-black-col">
                        <h1>Leveraging Technology For Supreme Woollen Processing</h1>
                     </div>
                  </div>
               </div> -->
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
            </a>
         </div>
      </section>
      <section class="container-x container-y clients">
         <!-- <h2>Our Clients</h2> -->
         <div class="owl-carousel owl-theme">
            <div class="item"> <img src="assets/images/Levis.png" alt="our_clients" /> </div>
            <div class="item"> <img src="assets/images/Columbia.png" alt="our_clients" /> </div>
            <div class="item"> <img src="assets/images/Aber.png" alt="our_clients" /> </div>
            <div class="item"> <img src="assets/images/Vans.png" alt="our_clients" /> </div>
            <div class="item"> <img src="assets/images/Superdry.png" alt="our_clients" /> </div>
            <div class="item"> <img src="assets/images/KC.png" alt="our_clients" /> </div>
            <div class="item"> <img src="assets/images/Gant.png" alt="our_clients" /> </div>
            <div class="item"> <img src="assets/images/img-gap.png" alt="our_clients" /> </div>
            <div class="item"> <img src="assets/images/cosco.png" alt="our_clients" /> </div>
         </div>
      </section>
      <section class="container-x product_up">
         <h2>Products</h2>
      </section>
      <section class="products" style="background-image:url(assets/images/Clothes.jpg)">
         <div class="flex-box">
            <div class="products-fabric ac"><a href="outerwear-apparel-fabrics.php">
               <img src="assets/images/Clothes.jpg" alt="Outerwear-Apparel Fabrics">
               <div class="overlay">
                  <h4>Outerwear/Apparel Fabrics</h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <span><a href="#">&#x2192;</a></span>
               </div></a>
            </div>
            <div class="products-fabric"><a href="sports-fabrics.php">
               <img src="assets/images/Sports-fabrics.jpg" alt="Sports Fabrics">
               <div class="overlay">
                  <h4>Sports Fabrics</h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <span><a href="#">&#x2192;</a></span>
               </div></a>
            </div>
            <div class="products-fabric"><a href="industrial-fabrics.php">
               <img src="assets/images/industrial-fabrics-banner.jpg" alt="Industrial Fabrics">
               <div class="overlay">
                  <h4>Industrial Fabrics</h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <span><a href="#">&#x2192;</a></span>
               </div></a>
            </div>
            <div class="products-fabric"><a href="flame-retardant-fabric.php">
               <img src="assets/images/Flame-Retardant (2).jpg" alt="Flame Retardant Fabric">
               <div class="overlay">
                  <h4>Flame Retardant Fabric</h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <span><a href="#">&#x2192;</a></span>
               </div></a>
            </div>
            <div class="products-fabric"><a href="institutional-fabrics.php">
               <img src="assets/images/Institutional.jpg" alt="Institutional Fabrics">
               <div class="overlay">
                  <h4>Institutional Fabrics</h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <span><a href="#">&#x2192;</a></span>
               </div></a>
            </div>
            <div class="products-fabric"><a href="blankets-and-shawls.php">
               <img src="assets/images/Blanket.jpg" alt="Blankets & Shawls">
               <div class="overlay">
                  <h4>Blankets & Shawls</h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <span><a href="#">&#x2192;</a></span>
               </div></a>
            </div>
            <div class="products-fabric"><a href="https://owncraft.in">
               <img src="assets/images/Woolen.jpg" alt="Woollen Garments">
               <div class="overlay">
                  <h4>Woollen Garments</h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <span><a href="#">&#x2192;</a></span>
               </div></a>
            </div>
            <div class="products-fabric"><a href="http://trinjann.com/">
               <img src="assets/images/Ethnic.jpg" alt="Ethnic Wear">
               <div class="overlay">
                  <h4>Ethnic Wear</h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <span><a href="#">&#x2192;</a></span>
               </div></a>
            </div>
         </div>
      </section>
      <section class="container-y services">
         <div class="flex-box">
            <div class="services-colm">
               <div class="center-text">
                  <h3>Services</h3>
                  <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
               </div>
            </div>
            <div class="services-colm">
               <img src="assets/images/fabric-manufacturing.jpg" alt="Fabric Manufacturing">
               <div class="padding">
                  <h3>Fabric Manufacturing</h3>
                  <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
               </div>
            </div>
            <div class="services-colm">
               <img src="assets/images/Fabric-Manufactring.jpg" alt="Woollen Processing">
               <div class="padding">
                  <h3>Processing & Finishing</h3>
                  <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
               </div>
            </div>
         </div>
      </section>
      <!-- <section class="container-x container-y mid">
         <div class="flex-box">
            <div class="about-col-lt"><img src="assets/images/About-us.png"></div>
            <div class="about-col-rt">
               <h2>About Us </h2>
               <p>We are an end to end manufacturer having capabilities across the value chain:</p>
               <ul>
                  <li>High quality fabric manufacturing: We have been continuously upgrading our machinery as well as innovation in our manufacturing processes and designs.  The daily production capacity has grown multifold over the years with the possibility to work with a wide variety of yarns like wool , polywool , polyester etc</li>
                  <li>Ability to provide high quality finished products with super premium finishes.</li>
                  <li>Garment design and manufacturing: We have our own garment brand, Own Craft where we produce a wide variety of woollen garments.</li>
                  <li>
                     Ethnic wear: Trinjann, intends to revitalize Phulkari-a rural tradition of needlework done by Punjabi women.
                  </li>
               </ul>
            </div>
         </div>
         </section>
         <section class="container-x container-y mid">
         <div class="flex-box">
            <div class="about-col-rt">
             
         
               <h2>Infrastructure</h2>
               <p>The Company has more than 1,50,000 sq. ft facilities in Amritsar. At Kochartex we provide direct/indirect employment to more than 800 people. Being an integrated manufacturing unit, Kochartex uses the best available technology in all the segments of the business, from Shuttle and Shuttleless looms to some of the most advanced machines in the Finishing setup .We also have a specialized section for the sampling needs of our clients. All the production processes are completely in compliance with the ISO 9001:2015 and Recyled Claim Standard (RCS) .Kochartex invests heavily not only on new plants and equipment, but also in the future of its people, who are encouraged to continuously upgrade their knowledge with regular sessions with industry experts.</p>
            </div>
            <div class="about-col-lt">
               <img src="assets\images\Infrastructure.png">
            </div>
         </div>
         </section>
         <section class="container-x container-y mid-white">
         <div class="flex-box">
            <div class="about-col-lt">
               <img src="assets\images\CSR.png">
            </div>
            <div class="about-col-rt">
               <h2>Abhay Kochar Foundation</h2>
               <p><b>Empowering Society With Education | Employment | Entrpreneurship </b></p>
               <p>We’re not just about manufacturing supreme fabric; we’re equally vested in delivering smiles & happiness to the society. At Kochar Abhay Foundation we’re closely associated with groups & institutions that are dedicated towards creating equal opportunities for specially abled & under privileged citizens around us.
                  A major part is involved nurturing & creating leaders for tomorrow. We do this under our entrepreneurship programs which not just limits to funding them; but also enabling them with people, processes & technology during their growth journey. 
               </p>
               <p>Here’s an overview of some our technology driven CSR Projects: </p>
               <ul>
                  <li>Project Drishti – An intelligent headgear that helps blind people to get vocal suggestion about the environment around them using AI & object detection</li>
                  <li>Project EduVan – A school on wheels, with screens & tablets that include educational content in visual formats & digital representation. This mobile school helps underprivileged kids with digital learning content </li>
               </ul>
            </div>
         </div>
         </section> -->
      <!--  <section class="container-x container-y csr">
         <p>Abhay Kochar Foundation is the corporate social responsibility (CSR) arm of the Kochar group, founded in 2018. It is dedicated to providing education, employment, and entrepreneurship to the underprivileged of society. </p>
         <div class="flex-box">
            <div class="csr-col">
               <h3>Project Drishti</h3>
               <div class="bg-white-content">
                  <img src="assets\images\drishti.jpg">
                  <p>Edu-van is a mobile classroom, designed and developed by Kochar. It is a self-learning management system equipped with laptops, tablets, and smartphones. These E-Vans are fully green and they move around in different locations. We are making sure the kids get used to the next generation learning system so they can also be part of the world of advancement.</p>
                 <div class="flex-box">
                     <div class="bar-img">
                        <img src="assets\images\sss.png">
                        <p>live voice assistant</p>
                     </div>
                     <div class="bar-img">
                        <img src="assets\images\sss.png">
                        <p>live voice assistant</p>
                     </div>
                     <div class="bar-img">
                        <img src="assets\images\sss.png">
                        <p>live voice assistant</p>
                     </div>
                     </div>
                  <a href="#">Know More</a>
               </div>
            </div>
            <div class="csr-col">
               <h3>Project Drishti</h3>
               <div class="bg-white-content">
                  <img src="assets\images\drishti.jpg">
                  <p>Edu-van is a mobile classroom, designed and developed by Kochar. It is a self-learning management system equipped with laptops, tablets, and smartphones. These E-Vans are fully green and they move around in different locations. We are making sure the kids get used to the next generation learning system so they can also be part of the world of advancement.</p>
               <div class="flex-box">
                     <div class="bar-img">
                        <img src="assets\images\sss.png">
                        <p>live voice assistant</p>
                     </div>
                     <div class="bar-img">
                        <img src="assets\images\sss.png">
                        <p>live voice assistant</p>
                     </div>
                     <div class="bar-img">
                        <img src="assets\images\sss.png">
                        <p>live voice assistant</p>
                     </div>
                     </div>
                  <a href="#">Know More</a>
               </div>
            </div>
            <div class="csr-col">
               <h3>Project Drishti</h3>
               <div class="bg-white-content">
                  <img src="assets\images\drishti.jpg">
                  <p>Edu-van is a mobile classroom, designed and developed by Kochar. It is a self-learning management system equipped with laptops, tablets, and smartphones. These E-Vans are fully green and they move around in different locations. We are making sure the kids get used to the next generation learning system so they can also be part of the world of advancement.</p>
                 <div class="flex-box">
                     <div class="bar-img">
                        <img src="assets\images\sss.png">
                        <p>live voice assistant</p>
                     </div>
                     <div class="bar-img">
                        <img src="assets\images\sss.png">
                        <p>live voice assistant</p>
                     </div>
                     <div class="bar-img">
                        <img src="assets\images\sss.png">
                        <p>live voice assistant</p>
                     </div>
                     </div> 
                  <a href="#">Know More</a>
               </div>
            </div>
         </div>
         </section>-->
      <section class="container-y container-x form" style="background-image:linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)), url(assets/images/img-bg-form.jpg);">
         <h2>Reach Us</h2>
         <div class="flex-box">
            <div class="form-col-lt">
               <div class="justify-block">
                  <div class="num">
                     <i class="fa fa-globe"></i>
                     <h3>18+</h3>
                     <p>countries</p>
                  </div>
                  <div class="num">
                     <i class="fa fa-group "></i>
                     <h3>200+</h3>
                     <p>Customers</p>
                  </div>
                  <div class="num">
                     <i class="fa fa-map"></i>
                     <h3>3 Mn meters+</h3>
                     <p>Fabric processed annually</p>
                  </div>
                  <div class="num">
                     <i class="fa fa-server"></i>
                     <h3>1.5 lac sqft</h3>
                     <p>production floors</p>
                  </div>
               </div>
            </div>
            <div class="form-col-rt">
               <form>                     
                  <input type="text" name="" placeholder="Name">
                  <input type="email" name="" placeholder="Email">
                  <input type="text" name="" placeholder="Phone number">
                  <textarea placeholder="Message"></textarea>
                  <input type="submit" value="Submit">
               </form>
            </div>
         </div>
      </section>
      <?php include 'footer.php';?>
      <script src="assets/js/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
      <script src="assets/js/owl.carousel.js"></script>
      <script>
         $('.owl-carousel').owlCarousel({
           loop: true,
           margin: 10,
           nav:false,
           dots:false,
           autoplay:true,
           autoplayTimeout:5000,
           responsiveClass: true,
           responsive: {
             0: {
               items: 2,
               margin: 3,
          
             },
             300: {
               items: 3,
               margin: 5,
         
             },
             1000: {
               items: 5,
         
             }
           }
         })
         
      </script>
   </body>
</html>
<script>
   jQuery('.products-fabric').hover(function() 
   { 
   
   //    jQuery(".products").animate({opacity: 0},1000,function(){
   //       var new1 = jQuery(this).find("img").attr('src');
   //       jQuery('.products').css("background-image", "url('"+new1+"')")
   //                .animate({opacity: 1},{duration:1000});
   //  });
   jQuery('.products').delay(200).addClass("a", 5000);
     var new1 = jQuery(this).find("img").attr('src');
       var f= jQuery('.products').css("background-image", "url('"+new1+"')");
      jQuery('.products-fabric').removeClass("ac")
   }); 
   
   
</script>