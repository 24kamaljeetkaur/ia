<!doctype html>
<html lang="en">
   <head>
      <title>Industrial Fabrics</title>
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="container-x container-y banner-prod" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/ic-bg-img.png);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Industrial Fabrics</h1>
            </div>
         </div>
      </section>
      <section class="container-x container-y product-woollentext">
         <div class="flex-box">
            <div class="inner-content">
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel metus eu varius. Praesent tortor justo, consectetur ac massa at, imperdiet ullamcorper odio. Curabitur venenatis arcu vitae lacus finibus tempus. Nunc suscipit ut risus ac fermentum. Proin non urna placerat, pharetra diam in, interdum ex. Etiam a efficitur est. Sed hendrerit imperdiet malesuada. In blandit quam vel odio hendrerit, vel vehicula felis iaculis. Nulla elementum eros quis dolor malesuada pulvinar.
</P>
            </div>
         </div>
      </section>
            <section class="container-x container-y blankets-mid">
         <div class="flex-box">
            <div class="about-col-lt"><img src="assets\images\ic.jpg" alt="Industrial Woven Fabrics"></div>
            <div class="about-col-rt">
               <h2>Advantages of Woven Industrial Fabrics</h2>

               <ul>

                  <li>Cost:  Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                  <li>Many Varied uses: Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                  <li>Environment Friendly:Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
               </ul>
            </div>
         </div>
      </section>
<section class="container-x container-y requestquote ">
         <div class="flex-box">
            <div class="requestquote-block">
               <img src="assets/images/black.jpg" alt="Endless Clearer cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="endless-clearer-cloth.php">Read More</a></div>
                  <h5>Endless Clearer cloth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg" alt="Green and White Clearer cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Green and White Clearer cloth</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg" alt="Frictional flannel">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Frictional flannel</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg" alt="Plaiding cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Plaiding cloth</h5>
               </div>
            </div>
            
         </div>

      </section> 
      <?php include 'footer.php';?>
   </body>
</html>