<!doctype html>
<html lang="en">
   <head>
      <title>Jacquard</title>
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="container-x container-y banner-prod" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/Jacquard-banner.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Jacquard Fabric</h1>
            </div>
         </div>
      </section>

      <section class="container-x container-y blankets-mid">
         <div class="flex-box">
            <div class="about-col-lt"><img src="assets\images\Jacquard.jpg" alt="Jacquard"></div>
            <div class="about-col-rt">
               <h2>Jacquard</h2>
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
            </div>
         </div>
      </section>
      <section class="container-x container-y requestquote ">
         <div class="flex-box">
            <div class="requestquote-block">
               <img src="assets/images/black.jpg" alt="Endless Clearer cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="endless-clearer-cloth.php">Request a Quote</a></div>
                  <h5>Lorem Ipsum is simply dummy text of</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg" alt="Green and White Clearer cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Lorem Ipsum is simply dummy text of</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg" alt="Frictional flannel">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Lorem Ipsum is simply dummy text of</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg" alt="Plaiding cloth">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="#">Request a Quote</a></div>
                  <h5>Lorem Ipsum is simply dummy text of</h5>
               </div>
            </div>
            
         </div>

      </section>



      <?php include 'footer.php';?>
   </body>
</html>