<!doctype html>
<html lang="en">
   <head>
      <title>Matty</title>
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="container-x container-y banner-prod" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/matty.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Matty Fabric</h1>
            </div>
         </div>
      </section>

      <!-- <section class="container-x container-y blankets-mid">
         <div class="flex-box">
            <div class="about-col-lt"><img src="assets\images\Matty.jpg" alt="Matty"></div>
            <div class="about-col-rt">
               <h2>Jacquard</h2>
               <p>We manufacture Jacquard fabrics which have interesting and complex patterns. Jacquard is woven into a fabric having different patterns such as damasks, floral, curvy and geometrical designs. Both sides of jacquard wool fabric can be used in manufacturing clothes or decorative items. Jacquard weaves have a varying drape ability and durability depending on which fibres are used. These jacquards are generally made of worsted, woollen yarns, regenerated fibre yarns in any composition basis the requirement from the customer. This fabric is manufactured with finest quality of raw material catering to customer’s specifications. You will find numerous styles and colors of Jacquard fabric in this section.</p>
            </div>
         </div>
      </section> -->




      <?php include 'footer.php';?>
   </body>
</html>