<!doctype html>
<html lang="en">
   <head>
      <title>Outerwear/Apparel Fabrics</title>
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="container-x container-y banner-prod" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/Clothes.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Outerwear/Apparel Fabrics</h1>
            </div>
         </div>
      </section>
      <section class="container-x container-y product-woollentext">
         <div class="flex-box">
            <div class="inner-content">
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
            </div>
         </div>
      </section>

      <section class="container-x container-y categories-listing">
         <div class="flex-box">
            <div class="cat-list-box">
            <a href="jacquard.php">
               <img src="assets\images\Jacquard.jpg">
               <div class="inner-content">
                  <h4>Lorem Ipsum </h4>
               </div></a>
            </div>
            <div class="cat-list-box">
            <a href="blazers.php">
               <img src="assets\images\blazer-fabric-thumb.jpg">
               <div class="inner-content">
                  <h4>Lorem Ipsum </h4>
               </div></a>
            </div>
            <div class="cat-list-box">
            <a href="tweed.php">
               <img src="assets\images\sf815.jpg">
               <div class="inner-content">
                  <h4>Lorem Ipsum </h4>
               </div></a>
            </div>
            <div class="cat-list-box">
            <a href="water-repellent-fabrics.php">
               <img src="assets\images\Water-resistance.jpg">
               <div class="inner-content">
                  <h4>Lorem Ipsum </h4>
               </div></a>
            </div>
            <div class="cat-list-box">
            <a href="shoe-lining.php">
               <img src="assets\images\Shoe-Lining.jpg">
               <div class="inner-content">
                  <h4>Lorem Ipsum </h4>
               </div></a>
            </div>
            <div class="cat-list-box">
            <a href="thermal-protective-clothing.php">
               <img src="assets\images\Thermal-Protector.jpg">
               <div class="inner-content">
                  <h4>Lorem Ipsum </h4>
               </div></a>
            </div>
         </div>
      </section>
      <?php include 'footer.php';?>
   </body>
</html>