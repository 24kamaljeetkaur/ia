<!doctype html>
<html lang="en">
   <head>
      <title>Products</title>

   </head>
   <body>
<?php include 'header.php';?>
      <section class="container-x container-y banner-prod" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/Blankets.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Products</h1>
            </div>
         </div>
      </section>
      <section class="container-x container-y product-woollentext">
         <div class="flex-box">
            <div class="inner-content">
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
            </div>
         </div>
      </section>
      <section class="container-x container-y blankets-mid">
         <div class="flex-box">
            <div class="about-col-lt"><img src="assets\images\non-woven-blanket-500x500.png"></div>
            <div class="about-col-rt">
               <h2>Shoddy Woollen Blankets</h2>
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
               <a href="shoddy-woollen-blankets.php">Know more</a>
            </div>
         </div>
      </section>
      <section class="container-x container-y blankets-mid">
         <div class="flex-box">
            <div class="about-col-lt">
               <img src="assets\images\throw.png">
            </div>
            <div class="about-col-rt">
               <h2>Throw Blankets</h2>
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries:</p>
               <ul>
                  <li>Large throw blankets are 40X60 inches</li>
                  <li>Small throw Blankets are  30×50 inches. </li>
               </ul>
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
               <a href="throw-blankets.php">Know more</a>
            </div>
         </div>
      </section>
       <?php include 'footer.php';?>

   </body>
</html>