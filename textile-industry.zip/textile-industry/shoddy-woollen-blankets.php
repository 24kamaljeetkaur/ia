<!doctype html>
<html lang="en">
   <head>
      <title>Shoddy Woollen Blankets</title>

   </head>
   <body>
<?php include 'header.php';?>
      <section class="container-x container-y banner-prodcat" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/Blankets.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prodcat-innercontent">
               <h1>Shoddy Woollen Blankets</h1>
            </div>
         </div>
      </section>
      <section class="container-x container-y shoddy-woollentext">
         <div class="flex-box">
            <div class="inner-content">
               <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
            </div>
         </div>
      </section>
      <section class="container-x container-y sorting">
         <div class="flex-box">
            <div class="sorting-lt">
               <p>Showing 1–12 of 45 results</p>
            </div>
            <div class="sorting-rt">
               <form>
                  <select name="orderby" class="orderby">
                     <option value="menu_order" selected="selected">Default sorting</option>
                     <option value="popularity">Sort by popularity</option>
                     <option value="rating">Sort by average rating</option>
                     <option value="date">Sort by newness</option>
                     <option value="price">Sort by price: low to high</option>
                     <option value="price-desc">Sort by price: high to low</option>
                  </select>
               </form>
            </div>
         </div>
      </section>
      <section class="container-x container-y requestquote ">
         <div class="flex-box">
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Beige Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Black Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Blue Grey Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Dark Red Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Grey Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Blue Wool Blazer</h5>
               </div>
            </div>
         </div>
         <div class="pagination">
            <a href="#">&#60;</a>
            <a href="#" class="active">1</a>
            <a href="#">2</a>
            <a href="#">3</a>
            <a href="#">4</a>
            <a href="#">5</a>
            <a href="#">6</a>
            <a href="#">&#62;</a>
         </div>
      </section>
 <?php include 'footer.php';?>

   </body>
</html>