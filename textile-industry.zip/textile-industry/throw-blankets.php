<!doctype html>
<html lang="en">
   <head>
      <title>Throw Blankets</title>
 
   </head>
   <body>
<?php include 'header.php';?>
      <section class="container-x container-y banner-prodcat" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/Blankets.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prodcat-innercontent">
               <h1>Throw Blankets</h1>
            </div>
         </div>
      </section>
      <section class="container-x container-y shoddy-woollentext">
         <div class="flex-box">
            <div class="inner-content">
               <p>We manufacture throw blankets with blend of wool and acrylic fibres. The throw blankets are available in 2 standard sizes:</p>
               <ul><li>Large throw blankets are 40X60 inches
</li>
<li>Small throw Blankets are 30×50 inches.</li></ul>
<p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

</p>
            </div>
         </div>
      </section>
      <section class="container-x container-y sorting">
         <div class="flex-box">
            <div class="sorting-lt">
               <p>Showing 1–12 of 45 results</p>
            </div>
            <div class="sorting-rt">
               <form>
                  <select name="orderby" class="orderby">
                     <option value="menu_order" selected="selected">Default sorting</option>
                     <option value="popularity">Sort by popularity</option>
                     <option value="rating">Sort by average rating</option>
                     <option value="date">Sort by newness</option>
                     <option value="price">Sort by price: low to high</option>
                     <option value="price-desc">Sort by price: high to low</option>
                  </select>
               </form>
            </div>
         </div>
      </section>
      <section class="container-x container-y requestquote ">
         <div class="flex-box">
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Beige Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Black Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Blue Grey Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Dark Red Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Grey Wool Blazer</h5>
               </div>
            </div>
            <div class="requestquote-block">
               <img src="assets/images/black.jpg">
               <div class="text-padding">
                  <div class="btn-overlay"><a href="beige-wool-blazer.php"> Request a Quote </a></div>
                  <h5>Blue Wool Blazer</h5>
               </div>
            </div>
         </div>
         <div class="pagination">
            <a href="#">&#60;</a>
            <a href="#" class="active">1</a>
            <a href="#">2</a>
            <a href="#">3</a>
            <a href="#">4</a>
            <a href="#">5</a>
            <a href="#">6</a>
            <a href="#">&#62;</a>
         </div>
      </section>
 <?php include 'footer.php';?>

   </body>
</html>