<!doctype html>
<html lang="en">
   <head>
      <title>Tweed</title>
   </head>
   <body>
      <?php include 'header.php';?>
      <section class="container-x container-y banner-prod" style="background-image: linear-gradient(to right,rgb(14 39 51 / 43%),rgb(27 44 62 / 58%),rgb(14 39 51 / 64%)),url(assets/images/tweed-banner.jpg);background-repeat: no-repeat;background-size: cover;background-position: center;">
         <div class="flex-box">
            <div class="prod-innercontent">
               <h1>Tweed Fabric</h1>
            </div>
         </div>
      </section>
      <section class="container-x container-y blankets-mid">
         <div class="flex-box">
            <div class="about-col-lt"><img src="assets\images\Tweed.jpg" alt="Tweed"></div>
            <div class="about-col-rt">
               <h2>Tweed</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel metus eu varius. Praesent tortor justo, consectetur ac massa at, imperdiet ullamcorper odio. Curabitur venenatis arcu vitae lacus finibus tempus. Nunc suscipit ut risus ac fermentum. Proin non urna placerat, pharetra diam in, interdum ex. Etiam a efficitur est. Sed hendrerit imperdiet malesuada. In blandit quam vel odio hendrerit, vel vehicula felis iaculis. Nulla elementum eros quis dolor malesuada pulvinar.

</p>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin elementum pulvinar lectus id lacinia. Ut rutrum vel metus eu varius. Praesent tortor justo, consectetur ac massa at, imperdiet ullamcorper odio. Curabitur venenatis arcu vitae lacus finibus tempus. Nunc suscipit ut risus ac fermentum. Proin non urna placerat, pharetra diam in, interdum ex. Etiam a efficitur est. Sed hendrerit imperdiet malesuada. In blandit quam vel odio hendrerit, vel vehicula felis iaculis. Nulla elementum eros quis dolor malesuada pulvinar.

</p>
            </div>
         </div>
      </section>
      <section class="container-x container-y categories-listing">
         <div class="flex-box">
            <div class="cat-list-box">
               <a href="check.php">
                  <img src="assets\images\checks.jpg">
                  <div class="inner-content">
                     <h4>Checks</h4>
                  </div>
               </a>
            </div>
            <div class="cat-list-box">
               <a href="houndstooth.php">
                  <img src="assets\images\Houndstooth.jpg">
                  <div class="inner-content">
                     <h4>Houndstooth</h4>
                  </div>
               </a>
            </div>
            <div class="cat-list-box">
               <a href="herringbone.php">
                  <img src="assets\images\Herringbone.jpg">
                  <div class="inner-content">
                     <h4>Herringbone</h4>
                  </div>
               </a>
            </div>
            <div class="cat-list-box">
               <a href="stripes.php">
                  <img src="assets\images\Stripes.jpg">
                  <div class="inner-content">
                     <h4>Stripes</h4>
                  </div>
               </a>
            </div>
            <div class="cat-list-box">
               <a href="twills.php">
                  <img src="assets\images\Twills.jpg">
                  <div class="inner-content">
                     <h4>Twills</h4>
                  </div>
               </a>
            </div>
            <div class="cat-list-box">
               <a href="matty.php">
                  <img src="assets\images\matty.jpg">
                  <div class="inner-content">
                     <h4>Matty</h4>
                  </div>
               </a>
            </div>
         </div>
      </section>

      <?php include 'footer.php';?>
   </body>
</html>