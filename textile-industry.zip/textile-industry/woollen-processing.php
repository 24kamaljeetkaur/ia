<!DOCTYPE html>
<html>
<head>
	<title>Woollen Processing</title>

</head>
<body>
<?php include 'header.php';?>
 <h1 style="padding-top: 80px;">Woollen Processing</h1>
 <?php include 'footer.php';?>
</body>
</html>